package ast;

import lexer.CommonConstants;

// C-> == G C | < G C | > G C | >= G C | <= G C | epsilon
public class C extends Tree {

    public enum OperatorType {EQUAL, LESS_THAN, GREATER_THAN, LESS_EQ_THAN, GREATER_EQ_THAN}

    public G g;
    public C c;
    public OperatorType o;

    public C(G g, C c, OperatorType o) {

        super(CommonConstants.AstNodeType.C);
        if (g != null)
            g.setParent(this);
        if (c != null)
            c.setParent(this);

        this.g = g;

        this.c = c;
        this.o = o;

    }

    public OperatorType getO() {
        return o;
    }

    @Override
    public int getLine() {
        return g.getLine();
    }

    @Override
    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }

}
