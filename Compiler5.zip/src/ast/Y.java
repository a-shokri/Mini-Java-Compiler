package ast;

import lexer.CommonConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Y extends Tree {


    public enum TYPE {
        LBR_EXP_RBR_Y, DOT_LENGTH_Y, DOT_IDENTIFIER_EXPRESSIONLIST_Y
    }

    public List<Object> content = new ArrayList<>();
    public TYPE type = null;

    public Y(TYPE type, Object... arg) {

        super(CommonConstants.AstNodeType.Q);
        this.type = type;

        switch (type) {

            case LBR_EXP_RBR_Y:
                content.add(arg[0]); // Exp
                content.add(arg[1]); // Y
                break;

            case DOT_LENGTH_Y:
                break;

            case DOT_IDENTIFIER_EXPRESSIONLIST_Y:
                content = Arrays.asList(arg);
                break;

        }

        if (content != null)
            for (Object object : content)
                if (object instanceof Tree)
                    ((Tree) object).setParent(this);
                else if (object instanceof List) {

                    for (Object object2 : (List) object)
                        if (object2 instanceof Tree)
                            ((Tree) object2).setParent(this);

                }

    }

    public TYPE getType() {
        return type;
    }

    @Override
    public int getLine() {
        return content != null && content.size() > 0 ? ((Tree) content.get(0)).getLine() : super.getLine();
    }

    @Override
    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }

}
