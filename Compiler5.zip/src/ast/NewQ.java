package ast;

import lexer.CommonConstants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// Q -> <INT_LIT> Y | "<STRING_LIT>" Y | true Y | false Y | Identifer Y | this Y | new Int [ E ] Y |
//      new Identifier() Y | ! E Y | ( E ) Y
//
public class NewQ extends Tree {

    public enum TYPE {
        INT_LIT, STRING_LIT, IDENTIFIER, THIS, TRUE, FALSE, NEW_INT_ARR, NEW_IDENTIFIER,
        NOT_EXP, LPR_EXP_RPR, BOOL_LIT
    }

    public List<Object> content = new ArrayList<>();
    public TYPE type;

    public NewQ(TYPE type, Object... arg) {

        super(CommonConstants.AstNodeType.NEWQ);
        this.type = type;

        if (arg != null && arg.length > 0) {

            content = Arrays.asList(arg);

            for (Object object :
                    content) {
                if (object instanceof Tree)
                    ((Tree) object).setParent(this);
            }

        }

    }


    public TYPE getType() {
        return type;
    }

    @Override
    public int getLine() {

        if (line > 0)
            return line;

        if (content != null && content.get(0) != null)
            return ((Tree) content.get(0)).getLine();

        return super.getLine();

    }

    @Override
    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }

}
