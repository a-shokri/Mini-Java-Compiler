package ast;

import lexer.CommonConstants;

public class G extends Tree {

    public H h;
    public D d;

    public G(H h, D d) {
        super(CommonConstants.AstNodeType.G);
        if (h != null)
            h.setParent(this);
        if (d != null)
            d.setParent(this);
        this.h = h;
        this.d = d;
    }
    @Override
    public int getLine() {
        return h.getLine();
    }

    @Override
    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }

}
