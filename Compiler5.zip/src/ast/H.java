package ast;

import lexer.CommonConstants;

// H -> Q J
public class H extends Tree {

    public NewQ q;
    public J j;

    public H(NewQ q, J j) {
        super(CommonConstants.AstNodeType.H);
        if (q != null)
            q.setParent(this);
        if (j != null)
            j.setParent(this);
        this.q = q;
        this.j = j;
    }
    @Override
    public int getLine() {
        return q.getLine();
    }

    @Override
    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }

}
