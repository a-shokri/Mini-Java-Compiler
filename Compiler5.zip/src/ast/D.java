package ast;

import lexer.CommonConstants;

// D-> + H D | - H D | epsilon
public class D extends Tree {

    public enum OperatorType {PLUS, MINUS}

    public H h;
    public D d;
    public OperatorType o;

    public D(H h, D d, OperatorType o) {

        super(CommonConstants.AstNodeType.D);
        if (h != null)
            h.setParent(this);
        if (d != null)
            d.setParent(this);
        this.h = h;
        this.d = d;
        this.o = o;

    }

    public OperatorType getO() {
        return o;
    }

    @Override
    public int getLine() {
        return h.getLine();
    }

    @Override
    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }

}
