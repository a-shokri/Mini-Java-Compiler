package ast;

import lexer.CommonConstants;

public class Expression extends Tree {

    public T t;
    public A a;

    public Expression(T t, A a) {

        super(CommonConstants.AstNodeType.EXPRESSION);
        if (a != null)
            a.setParent(this);
        if (t != null)
            t.setParent(this);
        this.a = a;
        this.t = t;

    }


    @Override
    public int getLine() {
        return t.getLine();
    }
    @Override
    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }

}
