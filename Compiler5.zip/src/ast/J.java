package ast;

import lexer.CommonConstants;

// J-> * Q J | / Q J | epsilon
public class J extends Tree {

    public enum OperatorType {MULTIPLY, DIVISION}

    public NewQ q;
    public J j;
    public OperatorType o;

    public J(NewQ q, J j, OperatorType o) {

        super(CommonConstants.AstNodeType.J);
        if (q != null)
            q.setParent(this);
        if (j != null)
            j.setParent(this);
        this.q = q;
        this.j = j;
        this.o = o;

    }

    public OperatorType getO() {
        return o;
    }
    @Override
    public int getLine() {
        return q.getLine();
    }

    @Override
    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }

}
