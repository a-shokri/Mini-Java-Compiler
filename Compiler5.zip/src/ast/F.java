package ast;

import lexer.CommonConstants;

// F -> G C
public class F extends Tree {

    public G g;
    public C c;

    public F(G g, C c) {
        super(CommonConstants.AstNodeType.F);
        if (g != null)
            g.setParent(this);
        if (c != null)
            c.setParent(this);
        this.g = g;
        this.c = c;
    }

    @Override
    public int getLine() {
        return g.getLine();
    }

    @Override
    public <R> R accept(Visitor<R> v) {
        return v.visit(this);
    }

}
