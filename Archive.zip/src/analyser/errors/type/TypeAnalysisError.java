package analyser.errors.type;

import analyser.errors.AnalysisError;

public abstract class TypeAnalysisError extends AnalysisError {


}
