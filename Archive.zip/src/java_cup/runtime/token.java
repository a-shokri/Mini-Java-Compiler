package java_cup.runtime;


public class token
        extends Symbol {
    public token(int term_num) {
        super(term_num);
    }
}
