package members;

public class EMJClass {
}
